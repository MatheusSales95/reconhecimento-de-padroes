# -*- coding: utf-8 -*-
"""Roda os pipelines e salva todas as figuras em PDF para o documento LaTeX."""
import warnings
warnings.filterwarnings('ignore')

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris, load_wine
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import pdist, squareform

OUT = '/home/claude/work/latex/figs'
os.makedirs(OUT, exist_ok=True)

np.random.seed(0)
plt.rcParams['figure.dpi'] = 110
plt.rcParams['savefig.bbox'] = 'tight'
plt.rcParams['font.size'] = 11


# ============== Utilitarios ==============
def best_match_accuracy(y_true, y_pred):
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row, col = linear_sum_assignment(w.max() - w)
    mapping = dict(zip(row, col))
    y_mapped = np.array([mapping[int(l)] for l in y_pred])
    acc = (y_mapped == y_true).mean()
    return acc, y_mapped


def metrics(y_true, y_pred):
    acc, ymap = best_match_accuracy(y_true, y_pred)
    ari = adjusted_rand_score(y_true, y_pred)
    nmi = normalized_mutual_info_score(y_true, y_pred)
    K = len(np.unique(y_pred))
    return K, acc, ari, nmi


# ============== Dados ==============
def load_and_prep(loader, name):
    data = loader()
    X_raw = data.data
    y = data.target
    X = StandardScaler().fit_transform(X_raw)
    X2 = PCA(n_components=2, random_state=0).fit_transform(X)
    return X, X2, y


X_iris, X2_iris, y_iris = load_and_prep(load_iris, 'Iris')
X_wine, X2_wine, y_wine = load_and_prep(load_wine, 'Wine')


# ---- Fig: dados originais ----
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
for ax, X2, y, name in [(axes[0], X2_iris, y_iris, 'Iris'),
                        (axes[1], X2_wine, y_wine, 'Wine')]:
    for c in np.unique(y):
        pos = y == c
        ax.scatter(X2[pos, 0], X2[pos, 1], s=30, alpha=0.85, label=f'classe {c}')
    ax.set_title(f'{name} -- PCA 2D com rotulos reais')
    ax.set_xlabel('PC1'); ax.set_ylabel('PC2'); ax.legend(); ax.grid(alpha=.3)
plt.savefig(f'{OUT}/dados_pca.pdf'); plt.close()


# ============== BSAS ==============
def BSAS(X, tau, max_clusters):
    m = X.shape[0]
    ind = -np.ones(m, dtype=int)
    mus = [X[0].copy()]; sizes = [1]; ind[0] = 0; c = 0
    for i in range(1, m):
        d = np.array([np.linalg.norm(X[i] - mu) for mu in mus])
        k = int(np.argmin(d))
        if d[k] > tau and (c + 1) < max_clusters:
            c += 1
            mus.append(X[i].copy()); sizes.append(1); ind[i] = c
        else:
            sizes[k] += 1
            mus[k] = mus[k] + (X[i] - mus[k]) / sizes[k]
            ind[i] = k
    return ind


def min_max_pairwise(X):
    D = squareform(pdist(X))
    Dnz = D + np.eye(D.shape[0]) * D.max()
    return Dnz.min(), D.max()


def tau_sweep(X, n_taus=80, n_reps=15, max_clusters=None):
    if max_clusters is None:
        max_clusters = X.shape[0]
    tau_min, tau_max = min_max_pairwise(X)
    taus = np.linspace(tau_min, tau_max, n_taus)
    counts = np.zeros(n_taus)
    for t_i, tau in enumerate(taus):
        vec = []
        for _ in range(n_reps):
            perm = np.random.permutation(X.shape[0])
            ind = BSAS(X[perm], tau, max_clusters)
            vec.append(len(np.unique(ind)))
        counts[t_i] = np.median(vec)
    return taus, counts


def estimate_k_from_plateau(taus, counts, min_len=3):
    dc = np.abs(np.diff(counts))
    segments = []
    i = 0; n = len(counts)
    while i < n:
        j = i
        while j + 1 < n and counts[j + 1] == counts[i]:
            j += 1
        segments.append((i, j, int(counts[i]), j - i + 1))
        i = j + 1
    cand = [s for s in segments if s[2] >= 2 and s[3] >= min_len]
    if not cand:
        cand = [s for s in segments if s[2] >= 2]
        if not cand:
            return int(counts.max()), segments, dc
    cand.sort(key=lambda s: (-s[3], s[2]))
    return cand[0][2], segments, dc


def plot_bsas_curve(taus, counts, dc, k_hat, name, fname):
    fig, ax1 = plt.subplots(figsize=(8, 3.8))
    ax1.plot(taus, counts, 'r-o', markersize=3, label=r'mediana de $c(\tau)$')
    ax1.axhline(k_hat, ls='--', color='k', alpha=.6, label=fr'$\hat k = {k_hat}$')
    ax1.set_xlabel(r'$\tau$'); ax1.set_ylabel(r'$c(\tau)$', color='r')
    ax1.grid(alpha=.3); ax1.legend(loc='upper right')
    ax2 = ax1.twinx()
    ax2.plot(taus[:-1], dc, 'b-', alpha=.5, label=r'$|\Delta c/\Delta \tau|$')
    ax2.set_ylabel(r'$|\Delta c/\Delta \tau|$', color='b')
    ax1.set_title(f'{name} -- curva BSAS e derivada discreta')
    fig.tight_layout(); plt.savefig(fname); plt.close()


# ---- BSAS Iris ----
print('BSAS Iris...')
taus_i, counts_i = tau_sweep(X_iris)
k_iris_q1, _, dc_i = estimate_k_from_plateau(taus_i, counts_i)
plot_bsas_curve(taus_i, counts_i, dc_i, k_iris_q1, 'Iris', f'{OUT}/bsas_curve_iris.pdf')
yhat_iris_q1 = AgglomerativeClustering(n_clusters=k_iris_q1, linkage='ward').fit_predict(X_iris)
print(f'  k_hat={k_iris_q1}', metrics(y_iris, yhat_iris_q1))

# ---- BSAS Wine ----
print('BSAS Wine...')
taus_w, counts_w = tau_sweep(X_wine)
k_wine_q1, _, dc_w = estimate_k_from_plateau(taus_w, counts_w)
plot_bsas_curve(taus_w, counts_w, dc_w, k_wine_q1, 'Wine', f'{OUT}/bsas_curve_wine.pdf')
yhat_wine_q1 = AgglomerativeClustering(n_clusters=k_wine_q1, linkage='ward').fit_predict(X_wine)
print(f'  k_hat={k_wine_q1}', metrics(y_wine, yhat_wine_q1))


# ---- Fig: comparacao de agrupamentos Q1 ----
def plot_clusters_pair(X2, y_true, y_pred, name, fname):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, y, title in [(axes[0], y_true, f'{name} -- rotulos reais'),
                         (axes[1], y_pred, f'{name} -- BSAS$\\to$Ward')]:
        for c in np.unique(y):
            pos = y == c
            ax.scatter(X2[pos, 0], X2[pos, 1], s=30, alpha=0.85, label=f'{c}')
        ax.set_xlabel('PC1'); ax.set_ylabel('PC2'); ax.set_title(title)
        ax.legend(); ax.grid(alpha=.3)
    plt.savefig(fname); plt.close()


plot_clusters_pair(X2_iris, y_iris, yhat_iris_q1, 'Iris', f'{OUT}/q1_iris_clusters.pdf')
plot_clusters_pair(X2_wine, y_wine, yhat_wine_q1, 'Wine', f'{OUT}/q1_wine_clusters.pdf')


# ============== Parzen ==============
def parzen_density(X, query, h):
    m, n = X.shape
    diff = (query[:, None, :] - X[None, :, :]) / h
    sqn = np.sum(diff * diff, axis=2)
    norm = (2 * np.pi) ** (n / 2)
    return np.sum(np.exp(-0.5 * sqn), axis=1) / (m * (h ** n) * norm)


def silverman_h(X):
    m, n = X.shape
    sigma = np.mean(np.std(X, axis=0))
    return sigma * (4.0 / ((n + 2) * m)) ** (1.0 / (n + 4))


def mean_shift_parzen(X, h, max_iter=300, tol=1e-4, merge_tol=None):
    m, n = X.shape
    if merge_tol is None:
        merge_tol = 0.5 * h
    points = X.copy()
    for _ in range(max_iter):
        diff = (points[:, None, :] - X[None, :, :]) / h
        w = np.exp(-0.5 * np.sum(diff * diff, axis=2))
        w_sum = w.sum(axis=1, keepdims=True) + 1e-12
        new_points = (w @ X) / w_sum
        shift = np.linalg.norm(new_points - points, axis=1).max()
        points = new_points
        if shift < tol:
            break
    modes = []
    labels = -np.ones(m, dtype=int)
    for i in range(m):
        assigned = False
        for mi, mode in enumerate(modes):
            if np.linalg.norm(points[i] - mode) < merge_tol:
                labels[i] = mi
                modes[mi] = (mode + points[i]) / 2
                assigned = True
                break
        if not assigned:
            modes.append(points[i].copy())
            labels[i] = len(modes) - 1
    return labels, np.array(modes)


def parzen_pipeline(X, y, name, alphas=(0.6, 0.8, 1.0, 1.3, 1.6, 2.0)):
    print(f'Parzen {name}...')
    h0 = silverman_h(X)
    rows = []
    best = None
    for a in alphas:
        h = a * h0
        lab, _ = mean_shift_parzen(X, h)
        K, acc, ari, nmi = metrics(y, lab)
        rows.append((a, h, K, acc, ari, nmi))
        if best is None or ari > best[4]:
            best = (a, h, K, acc, ari, lab)
        print(f'  a={a} h={h:.3f} K={K} acc*={acc:.3f} ARI={ari:.3f}')
    return best[5], best[1], rows


lab_parz_iris, h_iris, rows_pi = parzen_pipeline(X_iris, y_iris, 'Iris')
lab_parz_wine, h_wine, rows_pw = parzen_pipeline(X_wine, y_wine, 'Wine')


# ---- Fig: superficie de densidade de Parzen + agrupamento ----
def plot_parzen_density_2d(X, X2, y_pred, name, fname, h_factor=1.0):
    h = h_factor * silverman_h(X2)
    xmin, xmax = X2[:, 0].min() - 1, X2[:, 0].max() + 1
    ymin, ymax = X2[:, 1].min() - 1, X2[:, 1].max() + 1
    g = 130
    xs = np.linspace(xmin, xmax, g); ys = np.linspace(ymin, ymax, g)
    XX, YY = np.meshgrid(xs, ys)
    grid = np.c_[XX.ravel(), YY.ravel()]
    Z = parzen_density(X2, grid, h).reshape(g, g)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    ax = axes[0]
    ax.contourf(XX, YY, Z, levels=25, cmap='viridis')
    ax.scatter(X2[:, 0], X2[:, 1], c='white', s=10, alpha=0.7, edgecolor='k', lw=0.3)
    ax.set_title(f'{name} -- densidade Parzen (PCA 2D)')
    ax.set_xlabel('PC1'); ax.set_ylabel('PC2')

    ax = axes[1]
    for c in np.unique(y_pred):
        pos = y_pred == c
        ax.scatter(X2[pos, 0], X2[pos, 1], s=30, alpha=0.85, label=f'{c}')
    ax.set_title(f'{name} -- agrupamento Parzen mode-seeking')
    ax.set_xlabel('PC1'); ax.set_ylabel('PC2')
    if len(np.unique(y_pred)) <= 8:
        ax.legend(fontsize=8)
    ax.grid(alpha=.3)
    plt.savefig(fname); plt.close()


plot_parzen_density_2d(X_iris, X2_iris, lab_parz_iris, 'Iris', f'{OUT}/parzen_iris.pdf')
plot_parzen_density_2d(X_wine, X2_wine, lab_parz_wine, 'Wine', f'{OUT}/parzen_wine.pdf')


# ---- Fig: sensibilidade a h ----
def plot_h_sensitivity(rows_iris, rows_wine, fname):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
    for ax, rows, name in [(axes[0], rows_iris, 'Iris'), (axes[1], rows_wine, 'Wine')]:
        h = [r[1] for r in rows]
        K = [r[2] for r in rows]
        ari = [r[4] for r in rows]
        ax.plot(h, K, 'o-', color='C3', label='K (n. clusters)')
        ax.set_xlabel('h'); ax.set_ylabel('K', color='C3'); ax.grid(alpha=.3)
        ax2 = ax.twinx()
        ax2.plot(h, ari, 's-', color='C0', label='ARI')
        ax2.set_ylabel('ARI', color='C0')
        ax.set_title(f'{name} -- sensibilidade Parzen a h')
    plt.tight_layout(); plt.savefig(fname); plt.close()


plot_h_sensitivity(rows_pi, rows_pw, f'{OUT}/parzen_sensitivity.pdf')


# ============== KNN ==============
def knn_density(X, k):
    D = squareform(pdist(X))
    np.fill_diagonal(D, np.inf)
    rho = np.sort(D, axis=1)[:, k - 1]
    n = X.shape[1]
    p = k / (X.shape[0] * (rho ** n) + 1e-12)
    return p, D


def mutual_knn_graph(D, k):
    m = D.shape[0]
    idx = np.argsort(D, axis=1)[:, 1:k + 1]
    A = np.zeros((m, m), dtype=bool)
    for i in range(m):
        A[i, idx[i]] = True
    return A & A.T


def connected_components(A):
    m = A.shape[0]
    lab = -np.ones(m, dtype=int); cur = 0
    for i in range(m):
        if lab[i] != -1: continue
        stack = [i]
        while stack:
            v = stack.pop()
            if lab[v] != -1: continue
            lab[v] = cur
            stack.extend([u for u in np.where(A[v])[0] if lab[u] == -1])
        cur += 1
    return lab


def knn_cluster(X, k, p_low=10, min_size=3):
    m = X.shape[0]
    p, D = knn_density(X, k)
    thr = np.percentile(p, p_low)
    core = p >= thr
    A = mutual_knn_graph(D, k)
    A_core = A.copy()
    A_core[~core] = False
    A_core[:, ~core] = False
    lab_all = connected_components(A_core)
    labels = -np.ones(m, dtype=int)
    for i in range(m):
        if core[i]:
            labels[i] = lab_all[i]
    uniq, counts = np.unique(labels[labels >= 0], return_counts=True)
    small = set(uniq[counts < min_size].tolist())
    if small:
        big = [c for c in uniq if c not in small]
        if big:
            for i in range(m):
                if labels[i] in small:
                    dists_to_big = []
                    for c in big:
                        pos = np.where(labels == c)[0]
                        dists_to_big.append(D[i, pos].min())
                    labels[i] = big[int(np.argmin(dists_to_big))]
    noise_idx = np.where(labels == -1)[0]
    core_idx = np.where(labels >= 0)[0]
    if len(core_idx):
        for i in noise_idx:
            j = core_idx[np.argmin(D[i, core_idx])]
            labels[i] = labels[j]
    _, labels = np.unique(labels, return_inverse=True)
    return labels, p


def knn_pipeline(X, y, name, ks=(5, 7, 10, 15, 20, 30), p_low=10):
    print(f'KNN {name}...')
    rows = []
    best = None
    for k in ks:
        lab, p = knn_cluster(X, k, p_low=p_low)
        K, acc, ari, nmi = metrics(y, lab)
        rows.append((k, K, acc, ari, nmi, lab, p))
        if best is None or ari > best[3]:
            best = (k, K, acc, ari, nmi, lab, p)
        print(f'  k={k} K={K} acc*={acc:.3f} ARI={ari:.3f}')
    return best, rows


best_knn_iris, rows_ki = knn_pipeline(X_iris, y_iris, 'Iris')
best_knn_wine, rows_kw = knn_pipeline(X_wine, y_wine, 'Wine')
lab_knn_iris, p_iris = best_knn_iris[5], best_knn_iris[6]
lab_knn_wine, p_wine = best_knn_wine[5], best_knn_wine[6]


# ---- Fig: densidade KNN + agrupamento ----
def plot_knn(X2, p, y_pred, name, fname):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    ax = axes[0]
    sc = ax.scatter(X2[:, 0], X2[:, 1], c=p / p.max(), cmap='viridis', s=30, edgecolor='k', lw=0.2)
    plt.colorbar(sc, ax=ax, label=r'$\hat p_{KNN}$ normalizada')
    ax.set_title(f'{name} -- densidade via KNN'); ax.set_xlabel('PC1'); ax.set_ylabel('PC2')
    ax = axes[1]
    for c in np.unique(y_pred):
        pos = y_pred == c
        ax.scatter(X2[pos, 0], X2[pos, 1], s=30, alpha=0.85, label=f'{c}')
    ax.set_title(f'{name} -- agrupamento KNN (mkNN+densidade)')
    ax.set_xlabel('PC1'); ax.set_ylabel('PC2'); ax.legend(); ax.grid(alpha=.3)
    plt.savefig(fname); plt.close()


plot_knn(X2_iris, p_iris, lab_knn_iris, 'Iris', f'{OUT}/knn_iris.pdf')
plot_knn(X2_wine, p_wine, lab_knn_wine, 'Wine', f'{OUT}/knn_wine.pdf')


# ---- Fig: matrizes de confusao ----
def plot_cm_row(y_true, preds, titles, name, fname):
    fig, axes = plt.subplots(1, len(preds), figsize=(4.0 * len(preds), 3.6))
    for ax, y_pred, t in zip(axes, preds, titles):
        _, y_mapped = best_match_accuracy(y_true, y_pred)
        K = max(y_true.max(), y_mapped.max()) + 1
        cm = np.zeros((K, K), dtype=int)
        for a, b in zip(y_true, y_mapped):
            cm[a, b] += 1
        ax.imshow(cm, cmap='Blues')
        for i in range(K):
            for j in range(K):
                ax.text(j, i, cm[i, j], ha='center', va='center',
                        color='white' if cm[i, j] > cm.max() / 2 else 'black')
        ax.set_title(f'{name} -- {t}')
        ax.set_xlabel('predito'); ax.set_ylabel('verdadeiro')
        ax.set_xticks(range(K)); ax.set_yticks(range(K))
    plt.tight_layout(); plt.savefig(fname); plt.close()


plot_cm_row(y_iris, [yhat_iris_q1, lab_parz_iris, lab_knn_iris],
            ['BSAS$\\to$Ward', 'Parzen', 'KNN'], 'Iris', f'{OUT}/cm_iris.pdf')
plot_cm_row(y_wine, [yhat_wine_q1, lab_parz_wine, lab_knn_wine],
            ['BSAS$\\to$Ward', 'Parzen', 'KNN'], 'Wine', f'{OUT}/cm_wine.pdf')


# ============== Tabelas ==============
print('\n=== Resumo final ===')
res = {}
for name, y, preds in [('Iris', y_iris, [yhat_iris_q1, lab_parz_iris, lab_knn_iris]),
                       ('Wine', y_wine, [yhat_wine_q1, lab_parz_wine, lab_knn_wine])]:
    res[name] = []
    for method, yp in zip(['BSAS+Ward', 'Parzen', 'KNN'], preds):
        K, acc, ari, nmi = metrics(y, yp)
        res[name].append((method, K, acc, ari, nmi))
        print(f'  {name:5s}  {method:10s}  K={K}  acc*={acc:.3f}  ARI={ari:.3f}  NMI={nmi:.3f}')

# Salva CSV para inspecao
with open('/home/claude/work/latex/results.csv', 'w') as f:
    f.write('dataset,method,K,acc,ARI,NMI\n')
    for ds, rows in res.items():
        for m, K, acc, ari, nmi in rows:
            f.write(f'{ds},{m},{K},{acc:.4f},{ari:.4f},{nmi:.4f}\n')

print('\nFiguras salvas em', OUT)
